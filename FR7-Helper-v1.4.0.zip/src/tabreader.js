/* Opens a whitelisted page in a hidden, minimized window (never a tab in the user's own window), reads it, closes it.
   One window is reused for a burst of reads and closed a few seconds after the last one. Chrome-only. */
(function (root) {
  'use strict';
  const WL = root.FR7_WL, CFG = root.FR7_CONFIG;
  const err = (c) => Object.assign(new Error(c), { code: c });

  function waitComplete(tabId, deadline) {
    return new Promise((resolve, reject) => {
      let done = false;
      const finish = (fn, v) => { if (done) return; done = true; chrome.tabs.onUpdated.removeListener(on); clearTimeout(timer); fn(v); };
      const on = (id, info) => { if (id === tabId && info.status === 'complete') finish(resolve); };
      const timer = setTimeout(() => finish(reject, err('timeout')), Math.max(1, deadline - Date.now()));
      chrome.tabs.onUpdated.addListener(on);
      chrome.tabs.get(tabId).then((t) => { if (t && t.status === 'complete' && t.url && t.url !== 'about:blank') finish(resolve); }).catch(() => {});
    });
  }


  // ---- hidden reader window ----
  const KEY = 'fr7_reader_win'; let winId = null, inflight = 0, closeTimer = null;
  async function windowAlive(id) { if (id == null) return false; try { const w = await chrome.windows.get(id); return !!w; } catch (e) { return false; } }
  async function openHidden(url) {
    if (closeTimer) { clearTimeout(closeTimer); closeTimer = null; }
    try {
      if (!(await windowAlive(winId))) {
        const w = await chrome.windows.create({ url, state: 'minimized', focused: false });
        winId = w.id; try { await chrome.storage.session.set({ [KEY]: winId }); } catch (e) { /* optional */ }
        const t = (w.tabs && w.tabs[0]) || (await chrome.tabs.query({ windowId: w.id }))[0];
        if (t) return t;
      } else {
        return await chrome.tabs.create({ windowId: winId, url, active: false });
      }
    } catch (e) { winId = null; }
    return chrome.tabs.create({ url, active: false });   // fallback: a background tab
  }
  function scheduleClose() {
    if (inflight > 0) return; if (closeTimer) clearTimeout(closeTimer);
    closeTimer = setTimeout(async () => { closeTimer = null; if (inflight > 0) return; await cleanup(); }, 8000);
  }
  /** Close the hidden window (also called when the service worker starts, in case it was left open). */
  async function cleanup() {
    let id = winId; if (id == null) { try { id = (await chrome.storage.session.get(KEY))[KEY]; } catch (e) { /* none */ } }
    winId = null; try { await chrome.storage.session.remove(KEY); } catch (e) { /* none */ }
    if (id != null) { try { await chrome.windows.remove(id); } catch (e) { /* already closed */ } }
  }

  /** payload: {url, kind, wait_ms}. Returns {url,title,text,price,currency,stock,fields}. */
  async function readPage(payload, opts) {
    const cap = (opts && opts.capMs) || CFG.pageCapMs;
    const deadline = Date.now() + cap;
    let tab = null; inflight++;
    try {
      tab = await openHidden(payload.url);
      await waitComplete(tab.id, deadline);
      const cur = await chrome.tabs.get(tab.id);
      if (!WL.isShopUrl(cur.url || '')) throw err('redirected_outside_whitelist');
      const wait = Math.min(Math.max(0, Number(payload.wait_ms) || 0), 15000, Math.max(0, deadline - Date.now() - 2500));
      if (wait) await new Promise((r) => setTimeout(r, wait));
      const after = await chrome.tabs.get(tab.id);
      if (!WL.isShopUrl(after.url || '')) throw err('redirected_outside_whitelist');
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['src/whitelist.js', 'src/extract.js'] });
      const res = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => globalThis.FR7_EXTRACT.extractDoc(document, location.href) });
      const data = res && res[0] && res[0].result;
      if (!data) throw err('no_result');
      return data;
    } finally {
      if (tab && tab.id != null) { try { await chrome.tabs.remove(tab.id); } catch (e) { /* already closed */ } }
      inflight--; scheduleClose();
    }
  }

  /** Hidden-window fallback for eBay: returns { status, url, html } of the loaded page (outerHTML, capped). */
  async function readHtml(url, opts) {
    const cap = (opts && opts.capMs) || CFG.pageCapMs + 10000, deadline = Date.now() + cap;
    let tab = null; inflight++;
    try {
      tab = await openHidden(url); await waitComplete(tab.id, deadline);
      const cur = await chrome.tabs.get(tab.id); if (!WL.isShopUrl(cur.url || '')) throw err('redirected_outside_whitelist');
      await new Promise((r) => setTimeout(r, 1500));
      const res = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => document.documentElement.outerHTML.slice(0, 3 * 1024 * 1024) });
      const after = await chrome.tabs.get(tab.id);
      return { status: 200, url: after.url || url, html: (res && res[0] && res[0].result) || '' };
    } finally {
      if (tab && tab.id != null) { try { await chrome.tabs.remove(tab.id); } catch (e) { /* already closed */ } }
      inflight--; scheduleClose();
    }
  }
  /** One visible tab (used once when eBay shows a captcha, so the owner can solve it). */
  async function openVisible(url) { await chrome.tabs.create({ url, active: true }); }

  root.FR7_TABREADER = { readPage, readHtml, openVisible, cleanup };
})(globalThis);
