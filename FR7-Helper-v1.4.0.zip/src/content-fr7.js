/* Runs on FR7 website origins only. Answers the website's "hello" with version and paired. Pairing is by typed code in the popup only. */
(function () {
  'use strict';
  const ver = chrome.runtime.getManifest().version;
  const announce = (origin) => chrome.runtime.sendMessage({ type: 'status' }).then((s) => window.postMessage({ fr7: 'here', version: ver, paired: !!(s && s.paired) }, origin)).catch(() => window.postMessage({ fr7: 'here', version: ver, paired: false }, origin));
  window.addEventListener('message', (ev) => { if (ev.source !== window || !FR7_WL.isFr7Origin(ev.origin)) return; const d = ev.data; if (d && typeof d === 'object' && d.fr7 === 'hello') announce(ev.origin); });
  announce(location.origin);
})();
