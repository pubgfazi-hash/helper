/* FR7 Helper core: pairing, authed API calls, poll loop, task handling, heartbeat.
   All browser access is injected (storage, readPage, fetch, clock) so it runs in Node tests and in the service worker.
   Never logs tokens. Talks only to the paired server (an allowed FR7 origin). */
(function (root) {
  'use strict';
  const req = (n, g) => root[g] || (typeof require === 'function' ? require('./' + n) : null);
  const WL = req('whitelist', 'FR7_WL'), SIGN = req('sign', 'FR7_SIGN'), CFG = req('config', 'FR7_CONFIG');

  const KEYS = ['server', 'device_id', 'access', 'refresh', 'cmd_key'];

  function createCore(deps) {
    const fetchFn = deps.fetch, storage = deps.storage, readPage = deps.readPage;
    const version = deps.version || '0.0.0', name = deps.deviceName || 'Chrome helper';
    const now = deps.now || (() => Date.now());
    const sleep = deps.sleep || ((ms) => new Promise((r) => setTimeout(r, ms)));
    const cfg = deps.config || CFG, wl = deps.wl || WL, sign = deps.sign || SIGN;
    const onStatus = deps.onStatus || (() => {});
    const ebayResume = deps.ebayResume || null, readEbay = deps.readEbay || null, ebayDetect = deps.ebayDetect || null, ebayForget = deps.ebayForget || null;
    const log = deps.log || (() => {});

    let st = null;                 // cached state
    let running = false, stopFlag = false, backoffMs = 0, loopPromise = null;
    const siteChains = new Map(), inflight = new Set();
    let pollAbort = null;

    async function load() {
      if (st) return st;
      const raw = (await storage.get(KEYS)) || {};
      st = {};
      KEYS.forEach((k) => { if (raw[k]) st[k] = raw[k]; });
      if (st.server && !wl.cleanServer(st.server, cfg)) st = {};       // stored server no longer allowed (e.g. dev build removed)
      return st;
    }
    async function save(patch) {
      st = Object.assign(await load(), patch);
      const o = {}; KEYS.forEach((k) => { if (st[k]) o[k] = st[k]; });
      await storage.set(o);
    }
    async function clear() { st = {}; await storage.remove(KEYS); if (ebayForget) await ebayForget().catch(() => {}); onStatus({ paired: false }); }
    async function isPaired() { const s = await load(); return !!(s.server && s.access && s.refresh && s.cmd_key); }
    async function status() { const s = await load(); return { paired: await isPaired(), server: s.server || '', version }; }

    /** Pair with a code. `server` must be an allowed FR7 origin. The code alone decides: if the server accepts it, the helper is
        connected (no eBay login needed); if not, the helper refuses and says why. Spaces and dashes are ignored, and a lower-case
        code is also tried in upper case. Returns { ok } or { ok:false, error, message, status }. */
    async function pair(code, server) {
      const srv = wl.cleanServer(server, cfg);
      if (!srv) return { ok: false, error: 'server_not_allowed' };
      const raw = String(typeof code === 'string' ? code : '').replace(/[\s\-_]+/g, '');
      if (!/^[A-Za-z0-9]{4,32}$/.test(raw)) return { ok: false, error: 'bad_code' };
      const tries = [raw]; if (raw !== raw.toUpperCase()) tries.push(raw.toUpperCase());
      let last = { ok: false, error: 'pair_failed' };
      for (const c of tries) {
        let res;
        try {
          res = await fetchFn(srv + '/api/helper/register', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ code: c, name, version }) });
        } catch (e) { return { ok: false, error: 'network' }; }
        let j = null; try { j = await res.json(); } catch (e) { /* none */ }
        if (res.ok && j && j.access && j.refresh && j.cmd_key) {
          await clear();
          await save({ server: srv, device_id: j.device_id || '', access: j.access, refresh: j.refresh, cmd_key: j.cmd_key });
          onStatus({ paired: true });
          return { ok: true };
        }
        last = { ok: false, error: (j && j.error) || 'pair_failed', message: j && typeof j.message === 'string' ? j.message : undefined, status: res.status };
        if (res.status >= 500 || res.status === 429) break;   // server trouble: another spelling of the code will not help
      }
      return last;
    }

    async function refreshTokens() {
      const s = await load();
      let res;
      try { res = await fetchFn(s.server + '/api/helper/refresh', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ refresh: s.refresh }) }); }
      catch (e) { return 'network'; }
      if (res.status === 401 || res.status === 403 || res.status === 400) { await clear(); return 'revoked'; }
      let j = null; try { j = await res.json(); } catch (e) { /* none */ }
      if (!res.ok || !j || !j.access) return 'error';
      const patch = { access: j.access }; if (j.refresh) patch.refresh = j.refresh; if (j.cmd_key) patch.cmd_key = j.cmd_key;
      await save(patch);
      return 'ok';
    }

    /** Authenticated call to the paired server. Retries once after a token refresh. Returns {status, json}. */
    async function api(method, path, body, opts) {
      opts = opts || {};
      for (let attempt = 0; attempt < 2; attempt++) {
        const s = await load();
        if (!s.server || !s.access) throw Object.assign(new Error('not_paired'), { code: 'not_paired' });
        const ctl = typeof AbortController !== 'undefined' ? new AbortController() : null;
        if (opts.abortRef) opts.abortRef.ctl = ctl;
        const timer = ctl ? setTimeout(() => ctl.abort(), opts.timeoutMs || 15000) : null;
        let res;
        try {
          res = await fetchFn(s.server + path, { method, headers: Object.assign({ authorization: 'Bearer ' + s.access }, body !== undefined ? { 'content-type': 'application/json' } : {}), body: body !== undefined ? JSON.stringify(body) : undefined, signal: ctl ? ctl.signal : undefined });
        } finally { if (timer) clearTimeout(timer); }
        if (res.status === 401 && attempt === 0) {
          const r = await refreshTokens();
          if (r === 'ok') continue;
          throw Object.assign(new Error(r === 'revoked' ? 'not_paired' : 'refresh_failed'), { code: r === 'revoked' ? 'not_paired' : 'refresh_failed' });
        }
        let json = null; try { json = await res.json(); } catch (e) { /* no body */ }
        return { status: res.status, json };
      }
      throw new Error('auth_failed');
    }

    const postResult = (id, payload) => api('POST', '/api/helper/tasks/' + encodeURIComponent(id) + '/result', payload).catch((e) => log('result post failed', e.code || e.message));

    /** Validate and execute one task. Resolves when its result has been posted. */
    async function handleTask(task) {
      const s = await load();
      const nowSec = Math.floor(now() / 1000);
      const v = await sign.validateTask(task, s.cmd_key, nowSec, wl);
      if (!v.ok) {
        log('task dropped', v.reason);
        // Unsigned / forged tasks are ignored silently. Properly signed but unusable tasks get an error so the server can stop waiting.
        if (v.reason !== 'bad_signature' && v.reason !== 'malformed') await postResult(task.id, { ok: false, error: v.reason });
        return { dropped: v.reason };
      }
      if (inflight.has(task.id)) return { dropped: 'duplicate' };
      inflight.add(task.id);
      try {
        if (task.type === 'ping') { if (task.payload && task.payload.resume && ebayResume) ebayResume(); await postResult(task.id, { ok: true, data: { pong: true, version } }); return { done: true }; }
        const site = wl.siteOf(task.payload.url);
        return await runOnSite(site, async () => {
          let out;
          try {
            const data = readEbay && site === 'ebay' && (task.payload.kind === 'search' || task.payload.kind === 'sold') ? await readEbay(task.payload) : await readPage(task.payload, { capMs: cfg.pageCapMs });
            out = { ok: true, data };
          } catch (e) { out = { ok: false, error: String((e && e.code) || (e && e.message) || 'read_failed').slice(0, 100) }; }
          await postResult(task.id, out);
          return { done: out.ok };
        });
      } finally { inflight.delete(task.id); }
    }

    /** one task at a time per site */
    function runOnSite(site, fn) {
      const prev = siteChains.get(site) || Promise.resolve();
      const next = prev.then(fn, fn);
      const tail = next.catch(() => {});
      siteChains.set(site, tail);
      tail.then(() => { if (siteChains.get(site) === tail) siteChains.delete(site); });
      return next;
    }

    /** One long-poll. Returns number of tasks received. Throws on network/server error. */
    async function pollOnce() {
      const ref = {}; pollAbort = ref;
      const r = await api('GET', '/api/helper/poll?wait=' + cfg.pollWaitSeconds, undefined, { timeoutMs: (cfg.pollWaitSeconds + 12) * 1000, abortRef: ref });
      if (r.status >= 500 || r.status === 429) throw Object.assign(new Error('server_' + r.status), { code: 'server' });
      if (r.status !== 200 || !r.json) throw Object.assign(new Error('poll_' + r.status), { code: 'server' });
      const tasks = Array.isArray(r.json.tasks) ? r.json.tasks.slice(0, 10) : [];
      const pending = tasks.map((t) => handleTask(t).catch((e) => log('task error', e && e.message)));
      pending.forEach((p) => p.then(() => {}));
      if (deps.awaitTasks) await Promise.all(pending);
      return tasks.length;
    }

    async function runLoop() {
      if (running) return; running = true; stopFlag = false;
      try {
        while (!stopFlag && (await isPaired())) {
          try {
            const t0 = now(); const n = await pollOnce(); backoffMs = 0;
            if (n === 0 && now() - t0 < 500) await sleep(1000);   // server answered instantly with nothing: do not spin
          }
          catch (e) {
            if (e && e.code === 'not_paired') break;
            backoffMs = Math.min(backoffMs ? backoffMs * 2 : 1000, 60000);
            await sleep(backoffMs + Math.floor((deps.random ? deps.random() : Math.random()) * 250));
          }
          if (deps.maxLoops && --deps.maxLoops <= 0) break;
        }
      } finally { running = false; }
    }
    function ensureLoop() { if (!running) loopPromise = runLoop(); return loopPromise; }
    function stop() { stopFlag = true; if (pollAbort && pollAbort.ctl) try { pollAbort.ctl.abort(); } catch (e) { /* ignore */ } }

    async function heartbeat() {
      if (!(await isPaired())) return null;
      try {
        // No eBay login is sent: the helper works from its pairing code alone.
        const r = await api('POST', '/api/helper/heartbeat', { version });
        const need = !!(r.json && r.json.update_required);
        onStatus({ paired: true, updateRequired: need });
        return r.json;
      } catch (e) { return null; }
    }

    /* ---- calls made on behalf of the shop-page content script ---- */
    async function pageSeen(d) {
      if (!(await isPaired())) return { ask: false };
      const site = wl.siteOf(d && d.url);
      if (!site) return { ask: false };
      const body = { site, url: String(d.url).slice(0, 2000), title: String(d.title || '').slice(0, 500) };
      if (typeof d.price === 'number') body.price = d.price;
      if (d.currency) body.currency = String(d.currency).slice(0, 8);
      if (d.stock === 'in' || d.stock === 'out' || d.stock === 'unknown') body.stock = d.stock;
      try { const r = await api('POST', '/api/helper/page-seen', body); return r.status === 200 && r.json ? { ask: !!r.json.ask } : { ask: false }; }
      catch (e) { return { ask: false }; }
    }
    async function addMonitor(d) {
      const site = wl.siteOf(d && d.url);
      if (!site) return { ok: false, error: 'url_not_allowed' };
      const body = { url: String(d.url).slice(0, 2000), title: String(d.title || '').slice(0, 500), site };
      if (typeof d.price === 'number') body.price = d.price;
      if (d.currency) body.currency = String(d.currency).slice(0, 8);
      if (d.stock) body.stock = d.stock;
      try { const r = await api('POST', '/api/helper/monitor', body); return r.status === 200 && r.json && r.json.ok ? { ok: true } : { ok: false, error: (r.json && r.json.error) || 'failed' }; }
      catch (e) { return { ok: false, error: 'network' }; }
    }
    async function setSitePref(site) {
      if (!wl.SITES[site]) return { ok: false };
      try { const r = await api('POST', '/api/helper/site-pref', { site, ask: false }); return { ok: r.status === 200 }; } catch (e) { return { ok: false }; }
    }

    return { load, status, pair, clear, api, refreshTokens, handleTask, pollOnce, runLoop, ensureLoop, stop, heartbeat, pageSeen, addMonitor, setSitePref, isPaired, _state: () => st, _backoff: () => backoffMs };
  }

  const api = { createCore };
  root.FR7_CORE = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
