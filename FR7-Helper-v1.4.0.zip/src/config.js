/* FR7 Helper - the ONLY place that lists which servers/sites the helper talks to.
   Classic script (also imported as a side-effect module by the service worker). */
(function (root) {
  'use strict';
  const cfg = {
    // Origins of the FR7 website/server. The helper only pairs with and talks to these.
    origins: [
      'https://fr7navigator.com',
      'https://www.fr7navigator.com',
      'https://fr7-navigator.pubgfazi.workers.dev'
    ],
    // Dev flag: when true, http://localhost:<port> and http://127.0.0.1:<port> are also accepted.
    // Always false in the shipped extension; tools/make-dev.js builds a separate test copy with it on.
    devMode: false,
    pollWaitSeconds: 20,
    heartbeatMinutes: 3,
    pageCapMs: 20000,
    maxTextBytes: 200 * 1024,
    // eBay reading for Product Hunter: slow on purpose (random gap between pages), a daily page cap, and a pause after a captcha.
    ebayGapMinMs: 4000,
    ebayGapMaxMs: 9000,
    ebayDailyCap: 900,
    ebayCaptchaPauseMs: 3 * 60 * 1000,
    // Any page that needs an eBay login. If eBay sends the profile to its sign-in page, the profile is not logged in.
    ebayLoginUrl: 'https://www.ebay.com/mye/myebay/summary'
  };
  root.FR7_CONFIG = cfg;
  if (typeof module !== 'undefined' && module.exports) module.exports = cfg;
})(typeof globalThis !== 'undefined' ? globalThis : this);
