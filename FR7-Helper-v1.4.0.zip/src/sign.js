/* Task signature verification + task validation. WebCrypto only. */
(function (root) {
  'use strict';
  const ALLOWED_TYPES = ['read_page', 'ping'];
  const KINDS = ['product', 'tracking', 'search', 'sold', 'listing'];
  const enc = new TextEncoder();

  function hex(buf) { return Array.from(new Uint8Array(buf), (b) => b.toString(16).padStart(2, '0')).join(''); }

  async function hmacHex(key, msg) {
    const k = await crypto.subtle.importKey('raw', enc.encode(String(key)), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
    return hex(await crypto.subtle.sign('HMAC', k, enc.encode(msg)));
  }
  /** constant-time string compare (length leak only) */
  function timingSafeEqual(a, b) {
    a = String(a); b = String(b);
    let d = a.length ^ b.length;
    const n = Math.max(a.length, b.length);
    for (let i = 0; i < n; i++) d |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0);
    return d === 0;
  }
  const signedString = (t) => t.id + '|' + t.type + '|' + JSON.stringify(t.payload === undefined ? null : t.payload) + '|' + t.exp;

  async function verifySignature(task, cmdKey) {
    if (!task || !cmdKey || typeof task.sig !== 'string' || !/^[0-9a-f]{64}$/i.test(task.sig)) return false;
    const want = await hmacHex(cmdKey, signedString(task));
    return timingSafeEqual(want, task.sig.toLowerCase());
  }

  /** Returns {ok:true} or {ok:false, reason}. Order: shape, signature, expiry, type, url. */
  async function validateTask(task, cmdKey, nowSec, wl) {
    wl = wl || root.FR7_WL;
    if (!task || typeof task !== 'object' || typeof task.id !== 'string' || !task.id || typeof task.type !== 'string') return { ok: false, reason: 'malformed' };
    if (task.exp === undefined || task.exp === null || !/^\d{1,13}$/.test(String(task.exp))) return { ok: false, reason: 'malformed' };
    if (!(await verifySignature(task, cmdKey))) return { ok: false, reason: 'bad_signature' };
    let exp = Number(task.exp); if (exp > 1e11) exp = Math.floor(exp / 1000);   // tolerate ms
    if (exp <= nowSec) return { ok: false, reason: 'expired' };
    if (ALLOWED_TYPES.indexOf(task.type) < 0) return { ok: false, reason: 'type_not_allowed' };
    if (task.type === 'read_page') {
      const p = task.payload;
      if (!p || typeof p !== 'object' || typeof p.url !== 'string') return { ok: false, reason: 'bad_payload' };
      if (p.url.length > 2000 || !wl.isShopUrl(p.url)) return { ok: false, reason: 'url_not_allowed' };
      if (p.kind !== undefined && KINDS.indexOf(p.kind) < 0) return { ok: false, reason: 'bad_payload' };
      if (p.wait_ms !== undefined && !(Number.isFinite(p.wait_ms) && p.wait_ms >= 0)) return { ok: false, reason: 'bad_payload' };
    }
    return { ok: true };
  }

  const api = { ALLOWED_TYPES, hmacHex, timingSafeEqual, signedString, verifySignature, validateTask };
  root.FR7_SIGN = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
