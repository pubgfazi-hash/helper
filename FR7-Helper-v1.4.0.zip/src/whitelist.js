/* URL / origin checks. Pure functions, no chrome APIs. */
(function (root) {
  'use strict';
  const AMAZON = ['com', 'co.uk', 'de', 'ca', 'com.au', 'in', 'fr', 'it', 'es', 'nl', 'se', 'pl', 'com.mx', 'com.br', 'co.jp', 'sg', 'ae', 'sa', 'com.tr', 'com.be', 'eg'];
  const EBAY = ['com', 'co.uk', 'de', 'com.au', 'ca', 'fr', 'it', 'es', 'ie', 'at', 'ch', 'nl', 'pl', 'com.sg', 'com.hk', 'ph', 'com.my'];
  const SITES = {
    aliexpress: ['aliexpress.com', 'aliexpress.us'],
    amazon: AMAZON.map((t) => 'amazon.' + t),
    ebay: EBAY.map((t) => 'ebay.' + t),
    tiktok: ['tiktok.com'],
    walmart: ['walmart.com']
  };

  function parse(u) {
    try { return new URL(String(u)); } catch (e) { return null; }
  }
  function cleanHost(h) { return String(h || '').toLowerCase().replace(/\.$/, ''); }

  /** 'aliexpress' | 'amazon' | ... | '' for an https URL on a whitelisted shop. Rejects userinfo, odd ports, non-https. */
  function siteOf(u) {
    const p = parse(u);
    if (!p || p.protocol !== 'https:') return '';
    if (p.username || p.password) return '';
    if (p.port && p.port !== '443') return '';
    const h = cleanHost(p.hostname);
    if (!h || /[^a-z0-9.-]/.test(h)) return '';
    for (const site of Object.keys(SITES)) {
      for (const d of SITES[site]) if (h === d || h.endsWith('.' + d)) return site;
    }
    return '';
  }
  const isShopUrl = (u) => !!siteOf(u);

  /** Is `o` (an origin string such as "https://fr7navigator.com" or "http://localhost:8787") an allowed FR7 origin? */
  function isFr7Origin(o, cfg) {
    cfg = cfg || root.FR7_CONFIG;
    const p = parse(o);
    if (!p || p.origin === 'null' || p.origin !== String(o).replace(/\/+$/, '')) return false;
    if (cfg.origins.indexOf(p.origin) >= 0) return true;
    if (cfg.devMode && p.protocol === 'http:' && (p.hostname === 'localhost' || p.hostname === '127.0.0.1') && p.port) return true;
    return false;
  }
  /** Normalise a server value to an allowed origin string, or '' */
  function cleanServer(s, cfg) {
    const p = parse(s);
    if (!p || p.username || p.password) return '';
    if (p.pathname !== '/' || p.search || p.hash) return '';
    return isFr7Origin(p.origin, cfg) ? p.origin : '';
  }

  /** Product-page path rules per shop (used by the page content script). */
  function isProductPage(u) {
    const p = parse(u); const site = siteOf(u); if (!p || !site) return false;
    const path = p.pathname;
    switch (site) {
      case 'amazon': return /\/(dp|gp\/product|gp\/aw\/d)\/[A-Z0-9]{8,}/i.test(path);
      case 'aliexpress': return /\/item\/|\/i\/\d+\.html/i.test(path);
      case 'ebay': return /^\/itm\//i.test(path);
      case 'walmart': return /^\/ip\//i.test(path);
      case 'tiktok': return /\/(shop\/pdp|view\/product)\//i.test(path);
      default: return false;
    }
  }

  const api = { SITES, siteOf, isShopUrl, isFr7Origin, cleanServer, isProductPage };
  root.FR7_WL = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
