/* FR7 Helper service worker. No UI. */
importScripts('config.js', 'whitelist.js', 'sign.js', 'core.js', 'tabreader.js', 'ebay-parse.js', 'ebay.js');

const VERSION = chrome.runtime.getManifest().version;
const chromeStorage = {
  get: (k) => chrome.storage.local.get(k),
  set: (o) => chrome.storage.local.set(o),
  remove: (k) => chrome.storage.local.remove(k)
};

function setBadge(update) {
  chrome.action.setBadgeText({ text: update ? '!' : '' }).catch(() => {});
  if (update) chrome.action.setBadgeBackgroundColor({ color: '#c0392b' }).catch(() => {});
}

const ebay = FR7_EBAY.createEbayReader({ config: FR7_CONFIG, parse: FR7_EBAY_PARSE, fetch: (u, o) => fetch(u, o), storage: chromeStorage, readHtml: FR7_TABREADER.readHtml, openVisible: FR7_TABREADER.openVisible });

const core = FR7_CORE.createCore({
  readEbay: ebay.read,
  ebayResume: ebay.resume,
  
  fetch: (u, o) => fetch(u, o),
  storage: chromeStorage,
  readPage: FR7_TABREADER.readPage,
  version: VERSION,
  deviceName: 'Chrome helper',
  onStatus: (s) => { if (s.updateRequired !== undefined) setBadge(s.updateRequired); if (s.paired === false) setBadge(false); }
});

function schedule() {
  chrome.alarms.create('fr7-keepalive', { periodInMinutes: 0.5 });
  chrome.alarms.create('fr7-heartbeat', { periodInMinutes: FR7_CONFIG.heartbeatMinutes });
}
async function wake() { schedule(); core.ensureLoop(); }

chrome.runtime.onInstalled.addListener(() => { wake(); });
chrome.runtime.onStartup.addListener(() => { wake(); });
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === 'fr7-heartbeat') core.heartbeat();
  core.ensureLoop();
});
wake(); FR7_TABREADER.cleanup().catch(() => {});


const isFr7Sender = (sender) => sender && sender.tab && sender.url && FR7_WL.isFr7Origin(new URL(sender.url).origin);
const isShopSender = (sender) => sender && sender.tab && sender.url && FR7_WL.isShopUrl(sender.url);

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg || typeof msg.type !== 'string' || sender.id !== chrome.runtime.id) return false;
  (async () => {
    try {
      if (msg.type === 'status') return reply(await core.status());
      if (msg.type === 'pair-manual') {
        // From the helper's own popup only (an extension page, never a web page).
        if (sender.tab || !sender.url || !sender.url.startsWith(chrome.runtime.getURL('popup/'))) return reply({ ok: false, error: 'bad_sender' });
        const r = await core.pair(msg.code, msg.server);
        if (r.ok) { schedule(); core.ensureLoop(); core.heartbeat(); }
        return reply(r);
      }
      if (!isShopSender(sender)) return reply({ ok: false, ask: false });
      // Page data always uses the tab's own URL, never one supplied by the page script.
      const d = Object.assign({}, msg.data || {}, { url: sender.url });
      if (msg.type === 'page-seen') return reply(await core.pageSeen(d));
      if (msg.type === 'monitor') return reply(await core.addMonitor(d));
      if (msg.type === 'site-pref') return reply(await core.setSitePref(FR7_WL.siteOf(sender.url)));
      reply({ ok: false });
    } catch (e) { reply({ ok: false, error: 'internal' }); }
  })();
  return true;
});
