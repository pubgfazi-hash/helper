/* eBay reader for Product Hunter. Reads eBay search and sold pages with the eBay login of THIS Chrome profile.
   1. Background fetch (no window, no tab). 2. If eBay answers oddly, the hidden window as a fallback. 3. Captcha: pause, open ONE visible tab so the owner can solve it.
   Slow on purpose: a random gap between pages and a daily page cap. All browser access is injected, so it runs in Node tests too. */
(function (root) {
  'use strict';
  const err = (c) => Object.assign(new Error(c), { code: c });
  const DAY_KEY = 'fr7_ebay_day', ONCE_KEY = 'fr7_ebay_once';

  function createEbayReader(deps) {
    const cfg = deps.config, parse = deps.parse, fetchFn = deps.fetch, now = deps.now || (() => Date.now()), sleep = deps.sleep || ((ms) => new Promise((r) => setTimeout(r, ms))), rnd = deps.random || Math.random;
    const storage = deps.storage || { get: async () => ({}), set: async () => {} };
    let last = 0, pausedUntil = 0, lastVisible = 0, login = { login: null, checked_at: 0 };

    const hostOf = (u) => { try { return new URL(u).hostname.toLowerCase(); } catch (e) { return ''; } };
    const isSignin = (u) => { try { const x = new URL(u); return /^signin\./.test(x.hostname) || /\/signin|\/ws\/eBayISAPI\.dll/i.test(x.pathname) && /SignIn/i.test(x.search + x.pathname); } catch (e) { return false; } };

    async function gap() {
      const wait = last + cfg.ebayGapMinMs + rnd() * (cfg.ebayGapMaxMs - cfg.ebayGapMinMs) - now();
      if (wait > 0) await sleep(wait); last = now();
    }
    async function spendPage() {
      const d = new Date(now()).toISOString().slice(0, 10); let cur = null;
      try { cur = (await storage.get(DAY_KEY))[DAY_KEY]; } catch (e) { /* none */ }
      const n = cur && cur.d === d ? cur.n : 0; if (n >= cfg.ebayDailyCap) throw err('daily_cap');
      try { await storage.set({ [DAY_KEY]: { d, n: n + 1 } }); } catch (e) { /* optional */ }
    }
    async function fetchHtml(url) {
      const r = await fetchFn(url, { credentials: 'include', redirect: 'follow', headers: { accept: 'text/html,application/xhtml+xml', 'accept-language': 'en-US,en;q=0.9' } });
      const html = await r.text(); return { status: r.status, url: r.url || url, html: html.slice(0, 3 * 1024 * 1024) };
    }
    /** -> { ok, data } | { retry:true } (try the hidden window) ; throws for login / captcha */
    function classify(got, wantSold) {
      if (isSignin(got.url)) { login = { login: false, checked_at: now() }; throw err('ebay_not_logged_in'); }
      if (got.status === 403 || got.status === 429 || got.status === 503) return { captcha: true };
      const p = parse.parse(got.html, { sold: !!wantSold });
      if (p.login === false) { login = { login: false, checked_at: now() }; throw err('ebay_not_logged_in'); }
      if (p.captcha) return { captcha: true };
      if (p.unrecognized) return { retry: true };
      login = { login: true, checked_at: now() };
      return { ok: true, data: { url: got.url, title: 'eBay', ebay: { total: p.total, items: p.items, layout: p.layout, no_results: p.no_results } } };
    }
    async function captcha(url) {
      pausedUntil = now() + cfg.ebayCaptchaPauseMs;
      if (deps.openVisible && now() - lastVisible > 30 * 60 * 1000) { lastVisible = now(); try { await deps.openVisible(url); } catch (e) { /* ignore */ } }
      throw err('captcha');
    }

    /** payload: {url, kind: 'search'|'sold'}. Returns the page data for the server. */
    async function read(payload) {
      if (now() < pausedUntil) throw err('captcha_wait');
      await spendPage(); await gap();
      const sold = payload.kind === 'sold'; let got = null, res = null;
      try { got = await fetchHtml(payload.url); res = classify(got, sold); } catch (e) { if (e && (e.code === 'ebay_not_logged_in')) throw e; res = { retry: true }; }
      if (res.captcha) return captcha(payload.url);
      if (res.retry && deps.readHtml) {
        let h = null; try { h = await deps.readHtml(payload.url); } catch (e) { throw err((e && e.code) || 'read_failed'); }
        res = classify(h, sold); if (res.captcha) return captcha(payload.url);
      }
      if (!res.ok) throw err('unrecognized_page');
      return res.data;
    }

    /** Is this Chrome profile logged in to eBay? { login: true|false|null, checked_at }. Cached 3 minutes unless force. */
    async function check(force) {
      if (!force && login.login !== null && now() - login.checked_at < 3 * 60 * 1000) return login;
      try {
        const r = await fetchFn(cfg.ebayLoginUrl, { credentials: 'include', redirect: 'follow', headers: { accept: 'text/html' } });
        const html = (await r.text()).slice(0, 200000);
        const out = !isSignin(r.url || '') && r.status < 400 && !/(^|\s)(sign in|anmelden|connexion)/i.test(parse.text((/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html) || [])[1] || '')) && !/id="signin-form"|name="userid"/.test(html);
        login = { login: !!out, checked_at: now() };
      } catch (e) { login = { login: null, checked_at: now() }; }
      return login;
    }
    /** ONE-TIME detection, used only while this helper is not paired. The result is stored, so eBay is not asked again
        until the helper is unpaired or the owner presses "Check again" in the popup. A failed (offline) check is not stored. */
    async function stored() { try { const v = (await storage.get(ONCE_KEY))[ONCE_KEY]; return v && typeof v.login === 'boolean' ? v : null; } catch (e) { return null; } }
    async function detectOnce(force) {
      if (!force) { const s = await stored(); if (s) return s; }
      const r = await check(true); if (r.login === null) return { login: null, at: now() };
      const v = { login: !!r.login, at: now() }; try { await storage.set({ [ONCE_KEY]: v }); } catch (e) { /* optional */ }
      return v;
    }
    async function forget() { login = { login: null, checked_at: 0 }; try { if (storage.remove) await storage.remove(ONCE_KEY); } catch (e) { /* ignore */ } }
    /** The owner says the captcha is solved: stop pausing. */
    function resume() { pausedUntil = 0; return true; }
    return { read, check, resume, detectOnce, forget, state: () => login, _paused: () => pausedUntil };
  }

  const api = { createEbayReader };
  root.FR7_EBAY = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
