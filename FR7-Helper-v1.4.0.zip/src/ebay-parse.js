/* eBay search / sold page parser. Pure functions on an HTML string (no DOM), so it runs in the service worker and in Node tests.
   Understands both eBay result layouts (older "s-item" and newer "s-card"). Always fails soft: unknown markup -> { unrecognized: true }.
   NOTE: eBay changes its markup now and then. If hunts report "unrecognized", save a results page and update the selectors here. */
(function (root) {
  'use strict';
  const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };
  const decode = (s) => String(s == null ? '' : s).replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, e) => {
    if (e[0] === '#') { const n = e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10); return Number.isFinite(n) && n > 0 && n < 0x110000 ? String.fromCodePoint(n) : ' '; }
    return Object.prototype.hasOwnProperty.call(ENT, e.toLowerCase()) ? ENT[e.toLowerCase()] : m;
  });
  const text = (h) => decode(String(h == null ? '' : h).replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<style[\s\S]*?<\/style>/gi, ' ').replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim();

  /** "1,234.56" / "1.234,56" / "12,50" / "1.234" -> number, or null */
  function num(s) {
    let t = String(s == null ? '' : s).replace(/[^\d.,]/g, ''); if (!/\d/.test(t)) return null;
    const dot = t.lastIndexOf('.'), com = t.lastIndexOf(',');
    if (dot >= 0 && com >= 0) t = dot > com ? t.replace(/,/g, '') : t.replace(/\./g, '').replace(',', '.');
    else if (com >= 0) t = /,\d{1,2}$/.test(t) && (t.match(/,/g) || []).length === 1 ? t.replace(',', '.') : t.replace(/,/g, '');
    else if (dot >= 0 && /^\d{1,3}(\.\d{3})+$/.test(t)) t = t.replace(/\./g, '');
    const n = Number(t); return Number.isFinite(n) ? n : null;
  }
  function currencyOf(s) {
    const t = String(s || '');
    if (/\bAU\s*\$|AUD/.test(t)) return 'AUD'; if (/\bC\s*\$|CA\s*\$|CAD/.test(t)) return 'CAD'; if (/£|GBP/.test(t)) return 'GBP'; if (/€|EUR/.test(t)) return 'EUR'; if (/US\s*\$|USD|\$/.test(t)) return 'USD'; return '';
  }

  /** Inner HTML of the element that starts at html[at] === '<' (depth-counted on the same tag name). */
  function innerAt(html, at) {
    const open = /^<([a-zA-Z0-9]+)\b[^>]*>/.exec(html.slice(at, at + 2000)); if (!open) return '';
    const tag = open[1].toLowerCase(), start = at + open[0].length, re = new RegExp('<(/?)' + tag + '\\b[^>]*>', 'gi'); re.lastIndex = start; let depth = 1, m;
    while ((m = re.exec(html))) { if (m[1]) { depth--; if (!depth) return html.slice(start, m.index); } else if (!/\/>$/.test(m[0])) depth++; }
    return html.slice(start, start + 600);
  }
  /** Inner HTML of the first element whose class attribute matches `re`. */
  function byClass(html, re) {
    const t = /<([a-zA-Z0-9]+)\b[^>]*?\bclass="([^"]*)"[^>]*>/g; let m;
    while ((m = t.exec(html))) if (re.test(m[2])) return innerAt(html, m.index);
    return '';
  }

  const MONTHS = { jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5, jul: 6, aug: 7, sep: 8, sept: 8, oct: 9, nov: 10, dec: 11 };
  function dateOf(s) {
    let m = /([A-Za-z]{3,9})\.?\s+(\d{1,2}),?\s+(\d{4})/.exec(s), mo, d, y;
    if (m) { mo = MONTHS[m[1].slice(0, 4).toLowerCase()] ?? MONTHS[m[1].slice(0, 3).toLowerCase()]; d = +m[2]; y = +m[3]; }
    else { m = /(\d{1,2})\.?\s+([A-Za-z]{3,9})\.?,?\s+(\d{4})/.exec(s); if (!m) return null; d = +m[1]; mo = MONTHS[m[2].slice(0, 4).toLowerCase()] ?? MONTHS[m[2].slice(0, 3).toLowerCase()]; y = +m[3]; }
    if (mo == null || !(d >= 1 && d <= 31) || y < 2000) return null; return Math.floor(Date.UTC(y, mo, d) / 1000);
  }
  const SOLD_WORD = '(?:Sold|Verkauft|Vendu|Venduto|Vendido)';

  function parseItem(block) {
    const idm = /data-listingid="(\d{6,})"/.exec(block) || /\/itm\/(?:[^\/"?]*\/)?(\d{9,})/.exec(block); if (!idm) return null;
    const um = /href="(https:\/\/www\.ebay\.[a-z.]+\/itm\/[^"]+)"/.exec(block);
    let title = text(byClass(block, /(^|\s)(s-item__title|s-card__title)(\s|$)/)) || text((/<img[^>]*\balt="([^"]+)"/.exec(block) || [])[1] || '');
    title = title.replace(/^(New Listing|Neues Angebot|Nouvelle annonce|Nuova inserzione|Nuevo anuncio)\s*/i, '').replace(/\s*(Opens in a new window or tab|Wird in neuem Fenster oder Tab geöffnet).*$/i, '').trim();
    if (!title || /^Shop on eBay$/i.test(title)) return null;
    const priceTxt = text(byClass(block, /(^|\s)(s-item__price|s-card__price)(\s|$)/)), first = priceTxt.split(/\s(?:to|bis|à|a)\s/i)[0], cents = num(first);
    const plain = text(block), sold = new RegExp('(?<![\\d.,$£€])(\\d{1,3}(?:[.,]\\d{3})+|\\d+)\\s*([kK])?\\+?\\s+(?:sold|verkauft|vendus?|venduti|vendidos?)\\b', 'i').exec(plain);
    let soldQty = null; if (sold) { const n = num(sold[1]); if (n != null) soldQty = Math.round(n * (sold[2] ? 1000 : 1)); }
    const sd = new RegExp(SOLD_WORD + '\\s+(?:on\\s+|am\\s+|le\\s+|il\\s+|el\\s+)?([A-Za-z0-9äéû.,\\s]{6,24}?\\d{4})', 'i').exec(plain);
    const sellerTxt = text(byClass(block, /(^|\s)(s-item__seller-info-text|s-card__seller)(\s|$)/)) || plain, sm = /([A-Za-z0-9][A-Za-z0-9._\-*]{2,})\s*\(?\s*[\d.,]+[Kk]?\s*\)?\s*[\d.]+\s*%/.exec(sellerTxt);
    const loc = /\b(?:Located in|Item location:?|from)\s+([A-Z][A-Za-z]+(?: [A-Z][A-Za-z]+)?)/.exec(plain);
    let img = ''; const it = /<img\b[^>]*>/gi; let m; while ((m = it.exec(block))) { const s = /(?:data-src|src)="(https:\/\/i\.ebayimg\.com\/[^"]+)"/.exec(m[0].replace(/\bsrc="data:[^"]*"/, '')); if (s) { img = s[1]; break; } }
    return { id: idm[1], title: title.slice(0, 140), cents: cents == null ? null : Math.round(cents * 100), cur: currencyOf(priceTxt), sold_qty: soldQty, sold_at: sd ? dateOf(decode(sd[1])) : null, seller: sm ? sm[1].slice(0, 40) : '', ship_from: loc ? loc[1] : '', img: decode(img).slice(0, 300), url: um ? decode(um[1]).split('?')[0].slice(0, 300) : '' };
  }

  /** html -> { total, items, login, captcha, no_results, unrecognized, layout }. opts.sold marks a sold-listings page. */
  function parse(html, opts) {
    html = String(html == null ? '' : html); opts = opts || {};
    const title = text((/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html) || [])[1] || '');
    const out = { total: null, items: [], login: true, captcha: false, no_results: false, unrecognized: false, layout: '' };
    if (/(^|\s)(sign in|anmelden|connexion|accedi|iniciar sesi)/i.test(title) || /id="signin-form"|name="userid"|\/signin\.ebay\./i.test(html.slice(0, 120000)) && !/s-item|s-card/.test(html)) { out.login = false; return out; }
    const starts = [], re = /<li\b[^>]*\bclass="[^"]*\bs-(item|card)(?:\s[^"]*)?"[^>]*>/gi; let m;
    while ((m = re.exec(html))) { starts.push({ at: m.index, layout: m[1] }); }
    if (starts.length) out.layout = starts[0].layout === 'card' ? 's-card' : 's-item';
    for (let i = 0; i < starts.length && out.items.length < 240; i++) { const end = i + 1 < starts.length ? starts[i + 1].at : Math.min(html.length, starts[i].at + 12000), it = parseItem(html.slice(starts[i].at, Math.min(end, starts[i].at + 12000))); if (it) out.items.push(it); }
    const head = byClass(html, /(^|\s)srp-controls__count-heading(\s|$)/), cm = /([\d][\d.,\s ]*)\+?\s*(?:results?|Ergebnisse|résultats|risultati|resultados)/i.exec(text(head));
    if (cm) { const n = num(cm[1].replace(/[\s ]/g, '')); if (n != null) out.total = Math.round(n); }
    out.no_results = /srp-save-null-search|No exact matches found|did not match any items|keine Treffer|Aucun résultat/i.test(html);
    if (out.total == null && out.items.length) out.total = out.items.length;
    if (!out.items.length && out.no_results) out.total = 0;
    if (!out.items.length && !out.no_results) { out.captcha = /captcha|Pardon Our Interruption|Security Measure|splashui|verify yourself|Access Denied|unusual traffic/i.test(html) || html.length < 4000; out.unrecognized = !out.captcha; }
    return out;
  }

  const api = { parse, num, text, dateOf, currencyOf };
  root.FR7_EBAY_PARSE = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
