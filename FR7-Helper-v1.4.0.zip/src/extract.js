/* Page extraction. Pure parsing helpers (Node-testable) + extractDoc(doc, href) for a live DOM.
   Injected into a shop tab by the service worker, and used by the product-page content script.
   Reads only what is visible on the page. Sends nothing anywhere by itself. */
(function (root) {
  'use strict';
  const MAX_TEXT = 200 * 1024;

  const clean = (s) => String(s == null ? '' : s).replace(/\s+/g, ' ').trim();

  /** Cut a string so its UTF-8 size is <= maxBytes. */
  function clipBytes(s, maxBytes) {
    s = String(s || '');
    if (s.length * 3 <= maxBytes) return s;
    const enc = new TextEncoder();
    if (enc.encode(s).length <= maxBytes) return s;
    let lo = 0, hi = Math.min(s.length, maxBytes);
    while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (enc.encode(s.slice(0, mid)).length <= maxBytes) lo = mid; else hi = mid - 1; }
    return s.slice(0, lo);
  }

  const CUR_WORDS = { USD: 'USD', EUR: 'EUR', GBP: 'GBP', CAD: 'CAD', AUD: 'AUD', INR: 'INR', JPY: 'JPY', CNY: 'CNY', MXN: 'MXN', BRL: 'BRL', SEK: 'SEK', PLN: 'PLN', CHF: 'CHF', SGD: 'SGD', HKD: 'HKD', AED: 'AED', SAR: 'SAR', TRY: 'TRY', NZD: 'NZD' };

  /** Turn a number string in US or European notation into a Number, or null. */
  function toNumber(raw) {
    let s = String(raw).replace(/[^\d.,]/g, '');
    if (!s) return null;
    const lc = s.lastIndexOf(','), ld = s.lastIndexOf('.');
    if (lc >= 0 && ld >= 0) { s = lc > ld ? s.replace(/\./g, '').replace(',', '.') : s.replace(/,/g, ''); }
    else if (lc >= 0) { s = /,\d{1,2}$/.test(s) && (s.match(/,/g) || []).length === 1 ? s.replace(',', '.') : s.replace(/,/g, ''); }
    else if (ld >= 0 && (s.match(/\./g) || []).length > 1) { s = s.replace(/\./g, ''); }
    const n = parseFloat(s);
    return Number.isFinite(n) && n >= 0 ? n : null;
  }

  /** "US $12.99", "£1,299.00", "12,99 €", "$5.00 - $9.00" -> {price:12.99, currency:'USD'}. First price of a range wins. */
  function parsePrice(text, hintCurrency) {
    const t = clean(text);
    const none = { price: null, currency: hintCurrency || '' };
    if (!t) return none;
    const m = t.match(/\d[\d.,]*/);
    if (!m) return none;
    const price = toNumber(m[0]);
    if (price == null) return none;
    let currency = hintCurrency || '';
    const before = t.slice(0, m.index), after = t.slice(m.index + m[0].length);
    const around = before + ' ' + after.slice(0, 12);
    let w = around.match(/\b([A-Z]{3})\b/);
    if (w && CUR_WORDS[w[1]]) currency = w[1];
    else if (/\bCA\s?\$|\bC\s?\$/.test(around)) currency = 'CAD';
    else if (/\bAU\s?\$|\bA\s?\$/.test(around)) currency = 'AUD';
    else if (/\bUS\s?\$/.test(around)) currency = 'USD';
    else if (/£/.test(around)) currency = 'GBP';
    else if (/€/.test(around)) currency = 'EUR';
    else if (/₹|\bRs\.?/.test(around)) currency = 'INR';
    else if (/R\$/.test(around)) currency = 'BRL';
    else if (/\$/.test(around)) currency = currency || 'USD';
    return { price, currency };
  }

  /** From the text of all <script type="application/ld+json"> blocks, find the first Product and return its offer data. */
  function productFromLd(jsonTexts) {
    const stack = [];
    (jsonTexts || []).forEach((t) => { try { stack.push(JSON.parse(t)); } catch (e) { /* ignore broken block */ } });
    let guard = 0;
    while (stack.length && guard++ < 500) {
      const n = stack.shift();
      if (Array.isArray(n)) { stack.push.apply(stack, n); continue; }
      if (!n || typeof n !== 'object') continue;
      if (n['@graph']) stack.push(n['@graph']);
      const ty = [].concat(n['@type'] || []).join(',');
      if (/Product/i.test(ty) && !/ProductGroup/i.test(ty) || /ProductGroup/i.test(ty)) {
        let offer = n.offers; if (Array.isArray(offer)) offer = offer[0];
        if (!offer && Array.isArray(n.hasVariant)) { const v = n.hasVariant[0]; offer = v && (Array.isArray(v.offers) ? v.offers[0] : v.offers); }
        offer = offer || {};
        const ps = offer.priceSpecification && (Array.isArray(offer.priceSpecification) ? offer.priceSpecification[0] : offer.priceSpecification);
        const rawPrice = offer.price != null ? offer.price : offer.lowPrice != null ? offer.lowPrice : ps && ps.price;
        const out = {
          name: clean(n.name),
          price: rawPrice == null || rawPrice === '' ? null : toNumber(rawPrice),
          currency: clean(offer.priceCurrency || (ps && ps.priceCurrency) || ''),
          availability: String(offer.availability || '').replace(/^.*\//, '')
        };
        return out;
      }
    }
    return null;
  }

  const BLOCK_RE = /enter the characters you see below|type the characters you see|robot check|are you a human|unusual traffic|access denied|verify you are human|pardon our interruption|verify yourself|slide to verify|captcha/;
  const OUT_RE = /currently unavailable|out of stock|sold out|no longer available|temporarily unavailable|item is unavailable|this listing (was )?ended|listing has ended|bidding has ended|this product is no longer|not available for purchase/;

  /** Pure stock decision from signals. Returns 'in' | 'out' | 'unknown' */
  function decideStock(sig) {
    if (sig.blocked) return 'unknown';
    if (/OutOfStock|SoldOut|Discontinued/i.test(sig.availability || '')) return 'out';
    if (sig.outFlag) return 'out';
    if (sig.availText) {
      if (/currently unavailable|out of stock|unavailable|sold out/i.test(sig.availText)) return 'out';
      if (/in stock|only \d+ left|usually ships|available|last one|\d+ (pieces )?available/i.test(sig.availText)) return 'in';
    }
    if (sig.buyEnabled) return 'in';
    if (/InStock|LimitedAvailability|PreOrder|OnlineOnly/i.test(sig.availability || '')) return 'in';
    if (sig.buyDisabledOrOut) return 'out';
    if (OUT_RE.test(String(sig.lowerText || '').slice(0, 30000))) return 'out';
    return 'unknown';
  }

  function siteFromHost(host) {
    const h = String(host || '').toLowerCase();
    if (/(^|\.)aliexpress\.(com|us)$/.test(h)) return 'aliexpress';
    if (/(^|\.)amazon\.[a-z.]+$/.test(h)) return 'amazon';
    if (/(^|\.)ebay\.[a-z.]+$/.test(h)) return 'ebay';
    if (/(^|\.)tiktok\.com$/.test(h)) return 'tiktok';
    if (/(^|\.)walmart\.com$/.test(h)) return 'walmart';
    return '';
  }

  const SELECTORS = {
    amazon: {
      title: ['#productTitle', '#title', 'h1'],
      price: ['#corePrice_feature_div .a-price:not(.a-text-price) .a-offscreen', '#corePriceDisplay_desktop_feature_div .a-price:not(.a-text-price) .a-offscreen', '#apex_desktop .a-price:not(.a-text-price) .a-offscreen', '#priceblock_ourprice', '#priceblock_dealprice', '.a-price:not(.a-text-price) .a-offscreen'],
      avail: ['#availability'], out: ['#outOfStock'], buy: ['#add-to-cart-button', '#buy-now-button']
    },
    ebay: {
      title: ['h1.x-item-title__mainTitle', 'h1[data-testid="x-item-title"]', 'h1'],
      price: ['.x-price-primary', '[data-testid="x-price-primary"]', '[itemprop="price"]', 'meta[itemprop="price"]'],
      avail: ['.x-quantity__availability', '#qtyAvailability'], out: [], buy: ['a[href*="/bin/"]', '#binBtn_btn', '[data-testid="x-bin-action"] a, [data-testid="x-bin-action"] button']
    },
    aliexpress: {
      title: ['h1[data-pl="product-title"]', '.product-title-text', '[class*="title--wrap"] h1', 'h1'],
      price: ['[class*="price--current"]', '[class*="Price--current"]', '[class*="product-price-current"]', '.product-price-value', '[class*="price-default--current"]', '[class*="es--wrap"]'],
      avail: [], out: ['[class*="soldout" i]', '[class*="sold-out" i]'], buy: []
    },
    walmart: {
      title: ['h1[itemprop="name"]', 'h1#main-title', 'h1'],
      price: ['[itemprop="price"]', '[data-testid="price-wrap"] [itemprop="price"]', 'span[data-seo-id="hero-price"]', '[data-testid="price-wrap"]'],
      avail: [], out: ['[data-testid="out-of-stock"]'], buy: ['button[data-automation-id="atc"]', '[data-testid="add-to-cart-section"] button']
    },
    tiktok: {
      title: ['h1[class*="title" i]', '[data-e2e*="product-title" i]', 'h1'],
      price: ['[class*="price" i][class*="current" i]', '[data-e2e*="price" i]', '[class*="sale-price" i]', '[class*="Price" i]'],
      avail: [], out: ['[class*="sold-out" i]', '[class*="soldout" i]'], buy: []
    }
  };

  function extractDoc(doc, href) {
    href = href || (doc.location && doc.location.href) || '';
    let host = ''; try { host = new URL(href).hostname; } catch (e) { /* none */ }
    const site = siteFromHost(host);
    const S = SELECTORS[site] || { title: ['h1'], price: [], avail: [], out: [], buy: [] };
    const q = (s) => { try { return doc.querySelector(s); } catch (e) { return null; } };
    const txt = (el) => (el ? clean(el.getAttribute && el.tagName === 'META' ? el.getAttribute('content') : el.textContent) : '');
    const firstText = (list) => { for (const s of list) { const t = txt(q(s)); if (t) return t; } return ''; };

    const body = doc.body ? String(doc.body.innerText || doc.body.textContent || '') : '';
    const lower = body.toLowerCase();
    const ldTexts = Array.from(doc.querySelectorAll ? doc.querySelectorAll('script[type="application/ld+json"]') : []).map((s) => s.textContent || '');
    const ld = productFromLd(ldTexts);

    let title = firstText(S.title) || (ld && ld.name) || txt(q('meta[property="og:title"]')) || clean(doc.title);
    if (site === 'ebay') title = title.replace(/^Details about\s+/i, '').replace(/\s*\|\s*eBay.*$/i, '');
    if (site === 'amazon') title = title.replace(/^Amazon\.[a-z.]+\s*:\s*/i, '');

    let parsed = { price: null, currency: '' };
    for (const s of S.price) { const p = parsePrice(txt(q(s))); if (p.price != null) { parsed = p; break; } }
    if (parsed.price == null && ld && ld.price != null) parsed = { price: ld.price, currency: ld.currency || '' };
    if (parsed.price == null) {
      for (const s of ['[itemprop="price"]', 'meta[property="product:price:amount"]', 'meta[property="og:price:amount"]']) {
        const el = q(s); const p = parsePrice(el ? (el.getAttribute('content') || el.textContent) : '');
        if (p.price != null) { parsed = p; break; }
      }
    }
    if (parsed.price == null && site) {   // last resort: first money-looking value near the top of the visible text
      const mm = body.slice(0, 6000).match(/(?:US\s?|CA\s?|AU\s?)?[$£€]\s?\d[\d.,]*/); if (mm) parsed = parsePrice(mm[0]);
    }
    if (!parsed.currency) {
      parsed.currency = (ld && ld.currency) || clean((q('meta[itemprop="priceCurrency"], meta[property="product:price:currency"], meta[property="og:price:currency"]') || { getAttribute: () => '' }).getAttribute('content')) || '';
    }

    const blocked = BLOCK_RE.test(lower.slice(0, 6000)) && lower.length < 8000 && parsed.price == null;
    const availText = firstText(S.avail);
    const outFlag = S.out.some((s) => !!q(s)) || (site === 'ebay' && /this listing (was )?ended|this item is no longer available|listing has ended|bidding has ended/.test(lower.slice(0, 20000)));
    const buyEnabled = S.buy.some((s) => { const e = q(s); return e && !e.disabled && e.getAttribute('aria-disabled') !== 'true'; }) ||
      Array.from(doc.querySelectorAll ? doc.querySelectorAll('button, input[type=submit], a[role=button]') : []).some((b) => {
        const t = clean(b.value || b.getAttribute('aria-label') || b.textContent).toLowerCase();
        return /add to (cart|bag|basket|trolley)|buy now|buy it now/.test(t) && !b.disabled && b.getAttribute('aria-disabled') !== 'true';
      });
    const buyDisabledOrOut = Array.from(doc.querySelectorAll ? doc.querySelectorAll('button, input[type=submit], a[role=button]') : []).some((b) => /sold out|out of stock|notify me|email me when/.test(clean(b.value || b.getAttribute('aria-label') || b.textContent).toLowerCase()));
    const stock = decideStock({ blocked, availability: ld && ld.availability, outFlag, availText, buyEnabled: buyEnabled && !outFlag, buyDisabledOrOut, lowerText: lower });

    const fields = { site, host, stock_text: availText.slice(0, 120), blocked: !!blocked };
    if (site === 'amazon') { const m = href.match(/\/(?:dp|gp\/product|gp\/aw\/d)\/([A-Z0-9]{8,12})/i); if (m) fields.asin = m[1].toUpperCase(); }
    if (site === 'ebay') {
      const m = href.match(/\/itm\/(?:[^/?]+\/)?(\d{9,})/); if (m) fields.item_id = m[1];
      const mm = body.match(/(\d[\d,]*)\s+sold\b/i); if (mm) fields.sold = parseInt(mm[1].replace(/,/g, ''), 10);
    }
    if (site === 'walmart') { const m = href.match(/\/ip\/(?:[^/?]+\/)?(\d{5,})/); if (m) fields.item_id = m[1]; }
    if (site === 'aliexpress') { const m = href.match(/\/(?:item\/|i\/)(\d{6,})/); if (m) fields.item_id = m[1]; }
    const img = q('meta[property="og:image"]'); if (img) fields.image = txt(img).slice(0, 500);

    return {
      url: href, title: clean(title).slice(0, 500), text: clipBytes(body, MAX_TEXT),
      price: parsed.price, currency: parsed.currency || '', stock, fields
    };
  }

  const api = { MAX_TEXT, clean, clipBytes, toNumber, parsePrice, productFromLd, decideStock, siteFromHost, extractDoc };
  root.FR7_EXTRACT = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
