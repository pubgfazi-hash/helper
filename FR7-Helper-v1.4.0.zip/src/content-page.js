/* Runs on supported shop pages. When a product page has loaded it tells the paired server it was seen,
   and (only if the server says ask:true) shows a small prompt. Page content goes only to the helper's service worker. */
(function () {
  'use strict';
  if (window.__fr7PageLoaded) return; window.__fr7PageLoaded = true;
  let lastUrl = '', shown = false, timer = null, tries = 0;

  function send(type, data) { return chrome.runtime.sendMessage({ type, data }).catch(() => null); }

  function slim(d) { return { title: d.title, price: d.price, currency: d.currency, stock: d.stock }; }

  function prompt(data) {
    if (shown || document.getElementById('fr7-helper-prompt')) return; shown = true;
    const host = document.createElement('div'); host.id = 'fr7-helper-prompt';
    host.style.cssText = 'all:initial;position:fixed;right:16px;bottom:16px;z-index:2147483647;';
    const sh = host.attachShadow({ mode: 'closed' });
    const css = document.createElement('style');
    css.textContent = ':host{all:initial}*{box-sizing:border-box}.box{font:14px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;background:#fffaf0;color:#1c1b19;border:1px solid #ddd5c5;border-radius:14px;box-shadow:0 8px 28px rgba(28,27,25,.18);padding:16px;width:300px;-webkit-font-smoothing:antialiased}.t{margin:0 0 4px;font-size:15px;font-weight:700;letter-spacing:-.01em}.s{margin:0 0 14px;color:#6b665c;font-size:13px;line-height:1.4;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.s:empty{display:none}.r{display:flex;flex-wrap:wrap;align-items:center;gap:8px}button{font:inherit;font-size:13px;font-weight:600;cursor:pointer;height:34px;padding:0 14px;border-radius:9px;border:1px solid #1c1b19;background:transparent;color:#1c1b19}button.p{background:#1c1b19;color:#fffaf0}button.l{flex:1 0 100%;height:auto;margin-top:2px;padding:4px 0;border:0;font-weight:500;font-size:12.5px;color:#6b665c;text-align:left;text-decoration:underline}';
    const box = document.createElement('div'); box.className = 'box';
    const t = document.createElement('p'); t.className = 't'; t.textContent = 'Add this to FR7 Monitor?';
    const s = document.createElement('p'); s.className = 's'; s.textContent = (data.title || '').slice(0, 120);
    const row = document.createElement('div'); row.className = 'r';
    const mk = (cls, label, fn) => { const b = document.createElement('button'); b.type = 'button'; if (cls) b.className = cls; b.textContent = label; b.addEventListener('click', fn); row.appendChild(b); return b; };
    const close = () => host.remove();
    mk('p', 'Add', async () => {
      t.textContent = 'Adding...'; row.remove();
      const r = await send('monitor', slim(data));
      t.textContent = r && r.ok ? 'Added to FR7 Monitor.' : 'Could not add this page.'; s.textContent = '';
      setTimeout(close, 2500);
    });
    mk('', 'Not now', close);
    mk('l', "Don't ask on this shop", async () => { await send('site-pref', {}); close(); });
    box.append(t, s, row); sh.append(css, box);
    (document.body || document.documentElement).appendChild(host);
  }

  async function check() {
    const href = location.href;
    if (!FR7_WL.isProductPage(href)) { shown = false; lastUrl = ''; return; }
    if (href === lastUrl) return;
    const d = FR7_EXTRACT.extractDoc(document, href);
    if (!d.title || d.price == null) { if (++tries > 12) { lastUrl = href; tries = 0; } return; }   // product not shown yet; try again shortly
    lastUrl = href; tries = 0; shown = false;
    const r = await send('page-seen', slim(d));
    if (r && r.ask === true) prompt(d);
  }

  function start() { check(); timer = setInterval(check, 1500); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
