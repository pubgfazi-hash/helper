# FR7 Helper (Chrome extension) v1.3.0

A tiny helper that links this Chrome profile to your FR7 Navigator account. It never asks for passwords. **Install it in the Chrome profile where you are logged in to eBay**: Product Hunter uses that profile's eBay login to read eBay in the background. The helper never sends your eBay login to FR7.

## Install (Chrome "Load unpacked")
1. Unzip `helper-FR7-Helper.zip` into a folder, for example `Documents/FR7-Helper`. Keep that folder; Chrome reads it from there.
2. Open Chrome. Type `chrome://extensions` in the address bar and press Enter.
3. Turn on **Developer mode** (switch at the top right).
4. Click **Load unpacked**.
5. Choose the `FR7-Helper` folder (the one that contains `manifest.json`). Click Select.
6. "FR7 Helper" now shows in the list. Click the puzzle-piece icon in Chrome and pin it if you like.

## Connect (the code decides)
1. On https://fr7navigator.com: Settings, Browser helper, create a code (works once, 10 minutes).
2. Click the FR7 Helper icon, type the code, press Connect. The server accepts it or refuses with the reason. Any Chrome profile or computer; no eBay login or website tab needed to connect.

## What it does
- **Product Hunter:** reads eBay search and sold pages in the background (no window, no tab) with this profile's eBay login. Slow on purpose: a random 4 to 9 second gap between pages, at most 900 pages a day, and a pause after a captcha. If a captcha appears it opens ONE visible tab so you can solve it, then carries on.
- **eBay login:** looked at once while not connected (see Connect). It is not a condition for connecting and is not re-checked or sent to the server.
- Reads other supplier pages (Amazon, AliExpress, TikTok Shop, Walmart) only when your FR7 account asks, in a hidden window that closes by itself (Monitor and tracking).
- On a product page it can show "Add this to FR7 Monitor?" with Add / Not now / Don't ask on this shop.
- A red "!" on the icon means an update is needed: re-download the zip, replace the folder, and press the refresh arrow on chrome://extensions.

## Privacy
Page text goes only to your paired FR7 server. Commands are signed and checked; unsigned, expired or off-list ones are ignored. Tokens are never logged.

## For developers
`npm test` (parser, reader and task tests; the eBay pages in `test/fixtures.js` are hand-made, replace them with saved real pages when you can). If eBay changes its markup and hunts report an unrecognized page, update `src/ebay-parse.js`. Dev build for localhost: `node tools/make-dev.js <dir>`.
