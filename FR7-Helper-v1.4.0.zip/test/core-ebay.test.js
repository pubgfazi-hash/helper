import test from 'node:test'; import assert from 'node:assert/strict'; import { createRequire } from 'node:module';
const require = createRequire(import.meta.url), { createCore } = require('../src/core.js'), SIGN = require('../src/sign.js'), CFG = require('../src/config.js');
// An eBay hunt task goes to the eBay reader (not the old page reader), is signed, and its result is posted; the heartbeat reports the eBay login.
test('eBay search/sold tasks use the eBay reader; heartbeat carries the eBay login', async () => {
  const mem = {}, calls = []; const key = 'k'.repeat(32);
  const fetch = async (u, o) => { calls.push([u, o && o.method, o && o.body]); return { status: 200, ok: true, json: async () => ({ ok: true }) }; };
  const core = createCore({ fetch, storage: { get: async (k) => Object.fromEntries(k.map(x => [x, mem[x]]).filter(([, v]) => v)), set: async (o) => Object.assign(mem, o), remove: async (k) => k.forEach(x => delete mem[x]) },
    readPage: async () => { throw new Error('old reader must not be used'); }, readEbay: async (p) => ({ url: p.url, title: 'eBay', ebay: { total: 5, items: [] } }), version: '1.3.0', config: CFG });
  Object.assign(mem, { server: 'https://fr7navigator.com', access: 'a', refresh: 'r', cmd_key: key, device_id: 'd' });
  const task = { id: 't1', type: 'read_page', payload: { url: 'https://www.ebay.com/sch/i.html?_nkw=x', kind: 'search' }, exp: Math.floor(Date.now() / 1000) + 300 }; task.sig = await SIGN.hmacHex(key, SIGN.signedString(task));
  const r = await core.handleTask(task); assert.equal(r.done, true);
  const post = calls.find(c => c[0].endsWith('/api/helper/tasks/t1/result')); assert.ok(post); assert.equal(JSON.parse(post[2]).data.ebay.total, 5);
  await core.heartbeat(); const hb = calls.filter(c => c[0].endsWith('/api/helper/heartbeat')).pop(); assert.deepEqual(JSON.parse(hb[2]), { version: '1.3.0' });
  assert.equal((await core.status()).paired, true);
  const bad = { id: 't2', type: 'read_page', payload: { url: 'https://evil.example.com/x', kind: 'search' }, exp: Math.floor(Date.now() / 1000) + 300 }; bad.sig = await SIGN.hmacHex(key, SIGN.signedString(bad)); assert.equal((await core.handleTask(bad)).dropped, 'url_not_allowed');
});
