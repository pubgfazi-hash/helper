import test from 'node:test'; import assert from 'node:assert/strict'; import { createRequire } from 'node:module';
const require = createRequire(import.meta.url), { createCore } = require('../src/core.js'), { createEbayReader } = require('../src/ebay.js'), CFG = require('../src/config.js'), WL = require('../src/whitelist.js');
const mkStore = () => { const mem = {}; return { mem, get: async (k) => Object.fromEntries((Array.isArray(k) ? k : [k]).map(x => [x, mem[x]]).filter(([, v]) => v !== undefined)), set: async (o) => Object.assign(mem, o), remove: async (k) => (Array.isArray(k) ? k : [k]).forEach(x => delete mem[x]) }; };
const OK = { status: 200, ok: true, json: async () => ({ access: 'a', refresh: 'r', cmd_key: 'k'.repeat(32), device_id: 'd' }) };
const NO = { status: 400, ok: false, json: async () => ({ error: 'This pairing code is not valid or has expired' }) };
const SRV = 'https://fr7navigator.com';

test('a code the server accepts connects the helper, with no eBay login involved', async () => {
  const st = mkStore(); const bodies = [];
  const core = createCore({ fetch: async (u, o) => { bodies.push(JSON.parse(o.body)); return OK; }, storage: st, readPage: async () => ({}), version: '1.2.0', config: CFG });
  assert.deepEqual(await core.pair('ABCD2345', SRV), { ok: true });
  assert.equal(await core.isPaired(), true); assert.equal(bodies[0].code, 'ABCD2345');
});
test('spaces and dashes are ignored; a lower-case code is retried in upper case', async () => {
  const st = mkStore(); const sent = [];
  const core = createCore({ fetch: async (u, o) => { const c = JSON.parse(o.body).code; sent.push(c); return c === 'ABCD2345' ? OK : NO; }, storage: st, readPage: async () => ({}), config: CFG });
  assert.equal((await core.pair(' abcd-2345 ', SRV)).ok, true); assert.deepEqual(sent, ['abcd2345', 'ABCD2345']);
});
test('a code the server refuses is refused, with the server text and status', async () => {
  const core = createCore({ fetch: async () => NO, storage: mkStore(), readPage: async () => ({}), config: CFG });
  const r = await core.pair('ZZZZ9999', SRV); assert.equal(r.ok, false); assert.match(r.error, /not valid or has expired/); assert.equal(r.status, 400); assert.equal(await core.isPaired(), false);
});
test('bad shapes and unknown servers are refused before any request', async () => {
  let n = 0; const core = createCore({ fetch: async () => { n++; return OK; }, storage: mkStore(), readPage: async () => ({}), config: CFG });
  assert.equal((await core.pair('!!', SRV)).error, 'bad_code'); assert.equal((await core.pair('ABCD2345', 'https://evil.example.com')).error, 'server_not_allowed'); assert.equal(n, 0);
});
test('a signed ping with resume clears the captcha pause', async () => {
  const SIGN = require('../src/sign.js'); const st = mkStore(); const key = 'k'.repeat(32); let resumed = 0;
  const core = createCore({ fetch: async () => ({ status: 200, ok: true, json: async () => ({ ok: true }) }), storage: st, readPage: async () => ({}), ebayResume: () => { resumed++; }, config: CFG });
  Object.assign(st.mem, { server: SRV, access: 'a', refresh: 'r', cmd_key: key, device_id: 'd' });
  const task = { id: 'p1', type: 'ping', payload: { resume: true }, exp: Math.floor(Date.now() / 1000) + 300 }; task.sig = await SIGN.hmacHex(key, SIGN.signedString(task));
  assert.equal((await core.handleTask(task)).done, true); assert.equal(resumed, 1);
});
