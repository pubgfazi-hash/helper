import test from 'node:test'; import assert from 'node:assert/strict'; import { createRequire } from 'node:module';
import { OLD, SOLD, NONE, SIGNIN, CAPTCHA, ODD } from './fixtures.js';
const require = createRequire(import.meta.url), P = require('../src/ebay-parse.js'), { createEbayReader } = require('../src/ebay.js'), CFG = require('../src/config.js');
const mk = (pages, extra = {}) => {
  const log = { urls: [], sleeps: [], visible: [], windows: [] }, store = {}; let t = 1_800_000_000_000;
  const fetch = async (u) => { log.urls.push(u); const p = typeof pages === 'function' ? pages(u, log) : pages; return { status: p.status || 200, url: p.url || u, text: async () => p.html }; };
  const r = createEbayReader({ config: { ...CFG, ...(extra.cfg || {}) }, parse: P, fetch, now: () => t, sleep: async (ms) => { log.sleeps.push(ms); t += ms; }, random: () => 0.5, storage: { get: async (k) => ({ [k]: store[k] }), set: async (o) => Object.assign(store, o) },
    readHtml: extra.readHtml ? async (u) => { log.windows.push(u); return extra.readHtml(u); } : undefined, openVisible: async (u) => { log.visible.push(u); } });
  return { r, log, tick: (ms) => { t += ms; } };
};
const S = 'https://www.ebay.com/sch/i.html?_nkw=garlic';

test('reads a search page in the background and returns parsed items', async () => {
  const { r, log } = mk({ html: OLD }); const d = await r.read({ url: S, kind: 'search' });
  assert.equal(d.ebay.total, 1234); assert.equal(d.ebay.items.length, 2); assert.equal(log.windows.length, 0); assert.equal(r.state().login, true);
});
test('slow on purpose: a random gap between pages', async () => {
  const { r, log } = mk({ html: OLD }); await r.read({ url: S, kind: 'search' }); await r.read({ url: S, kind: 'sold' });
  assert.ok(log.sleeps.length >= 1 && log.sleeps.every(ms => ms >= 3000 && ms <= 9000), JSON.stringify(log.sleeps));
});
test('zero results is a real answer, not an error', async () => { const { r } = mk({ html: NONE }); const d = await r.read({ url: S, kind: 'search' }); assert.equal(d.ebay.total, 0); assert.equal(d.ebay.items.length, 0); });
test('not logged in: redirect to sign-in or sign-in page -> ebay_not_logged_in', async () => {
  const a = mk({ html: '<html></html>', url: 'https://signin.ebay.com/ws/eBayISAPI.dll?SignIn' }); await assert.rejects(a.r.read({ url: S, kind: 'sold' }), { code: 'ebay_not_logged_in' }); assert.equal(a.r.state().login, false);
  const b = mk({ html: SIGNIN }); await assert.rejects(b.r.read({ url: S, kind: 'sold' }), { code: 'ebay_not_logged_in' });
});
test('captcha: pauses, opens ONE visible tab, then refuses quickly while paused', async () => {
  const { r, log, tick } = mk({ html: CAPTCHA }); await assert.rejects(r.read({ url: S, kind: 'search' }), { code: 'captcha' }); assert.equal(log.visible.length, 1);
  await assert.rejects(r.read({ url: S, kind: 'search' }), { code: 'captcha_wait' }); assert.equal(log.urls.length, 1, 'no page is requested while paused'); assert.equal(log.visible.length, 1);
  tick(11 * 60 * 1000); await assert.rejects(r.read({ url: S, kind: 'search' }), { code: 'captcha' }); assert.equal(log.visible.length, 1, 'visible tab at most once per 30 minutes');
  const h = mk({ html: '', status: 429 }); await assert.rejects(h.r.read({ url: S, kind: 'search' }), { code: 'captcha' });
});
test('unknown page: falls back to the hidden window; if that is also unknown -> unrecognized_page', async () => {
  const a = mk({ html: ODD }, { readHtml: async (u) => ({ status: 200, url: u, html: OLD }) }); const d = await a.r.read({ url: S, kind: 'search' }); assert.equal(d.ebay.items.length, 2); assert.equal(a.log.windows.length, 1);
  const b = mk({ html: ODD }, { readHtml: async (u) => ({ status: 200, url: u, html: ODD }) }); await assert.rejects(b.r.read({ url: S, kind: 'search' }), { code: 'unrecognized_page' });
});
test('daily page cap', async () => { const { r } = mk({ html: OLD }, { cfg: { ebayDailyCap: 2 } }); await r.read({ url: S, kind: 'search' }); await r.read({ url: S, kind: 'search' }); await assert.rejects(r.read({ url: S, kind: 'search' }), { code: 'daily_cap' }); });
test('login check: logged in, logged out, network error, cached', async () => {
  const a = mk({ html: '<html><head><title>My eBay</title></head></html>' }); assert.equal((await a.r.check(true)).login, true); const n = a.log.urls.length; await a.r.check(false); assert.equal(a.log.urls.length, n, 'cached for 3 minutes');
  const b = mk({ html: '<html></html>', url: 'https://signin.ebay.com/ws/eBayISAPI.dll?SignIn&ru=x' }); assert.equal((await b.r.check(true)).login, false);
  const c = mk(() => { throw new Error('net'); }); assert.equal((await c.r.check(true)).login, null);
});
