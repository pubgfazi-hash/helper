// Hand-made eBay page samples (both layouts). They mirror eBay's markup as of writing; replace with saved real pages when you have them.
export const OLD = `<html><head><title>garlic press for sale | eBay</title></head><body>
<h1 class="srp-controls__count-heading"><span class="BOLD">1,234</span><span class="BOLD"> results</span> for garlic press</h1>
<ul class="srp-results">
<li class="s-item s-item__pl-on-bottom" data-listingid="123456"><div class="s-item__wrapper"><div class="s-item__info"><div class="s-item__title"><span role="heading">Shop on eBay</span></div><span class="s-item__price">$20.00</span></div></div></li>
<li class="s-item s-item__pl-on-bottom" data-listingid="111111111111"><div class="s-item__wrapper"><div class="s-item__image-wrapper"><img src="https://i.ebayimg.com/images/g/abc/s-l225.jpg" class="s-item__image-img" alt="x"></div>
<div class="s-item__info"><a class="s-item__link" href="https://www.ebay.com/itm/111111111111?hash=item1&amp;x=2"><div class="s-item__title"><span class="LIGHT_HIGHLIGHT">New Listing</span><span role="heading" aria-level="3">Silicone Garlic Press &amp; Peeler</span><span class="clipped">Opens in a new window or tab</span></div></a>
<div class="s-item__details"><span class="s-item__price">$12.99</span><span class="s-item__quantitySold">1,234 sold</span><span class="s-item__seller-info-text">gadgetshop (5,432) 99.5%</span><span class="s-item__location">from China</span></div></div></div></li>
<li class="s-item s-item__pl-on-bottom"><div class="s-item__info"><a class="s-item__link" href="https://www.ebay.com/itm/Garlic-Rocker/222222222222?hash=x"><div class="s-item__title"><span role="heading">Garlic Rocker</span></div></a><span class="s-item__price">$8.00 to $10.00</span><span class="s-item__seller-info-text">kitchenking (88) 100%</span></div></li>
</ul></body></html>`;
export const NEW = `<html><head><title>garlic for sale | eBay</title></head><body>
<h1 class="srp-controls__count-heading"><span class="BOLD">45</span> results for garlic</h1>
<ul><li class="s-card s-card--horizontal" data-listingid="333333333333"><div class="su-card-container"><div class="s-card__image"><img src="data:image/gif;base64,R0lG" data-src="https://i.ebayimg.com/images/g/zz/s-l500.jpg"></div>
<div class="su-card-container__content"><a class="s-card__link" href="https://www.ebay.com/itm/333333333333?x=1"><div class="s-card__title"><span class="su-styled-text primary default">Garlic Mincer Tool</span></div></a>
<div class="s-card__attribute-row"><span class="s-card__price">$8.50</span></div><div class="s-card__attribute-row"><span class="su-styled-text">Sold Nov 20, 2026</span></div><div class="s-card__attribute-row"><span>12 sold</span><span>Located in Germany</span></div></div></div></li></ul></body></html>`;
export const SOLD = `<html><head><title>garlic press | eBay</title></head><body><h1 class="srp-controls__count-heading"><span class="BOLD">3,010</span> results</h1><ul>
<li class="s-item" data-listingid="444444444444"><a href="https://www.ebay.com/itm/444444444444"><div class="s-item__title"><span role="heading">Garlic Press A</span></div></a><span class="s-item__price">$14.00</span><div class="s-item__caption">Sold Nov 20, 2026</div></li>
<li class="s-item" data-listingid="555555555555"><a href="https://www.ebay.com/itm/555555555555"><div class="s-item__title"><span role="heading">Garlic Press B</span></div></a><span class="s-item__price">$16.00</span><div class="s-item__caption">Sold 3 Oct 2026</div></li></ul></body></html>`;
export const NONE = `<html><head><title>x | eBay</title></head><body><div class="srp-save-null-search">No exact matches found</div><h1 class="srp-controls__count-heading"><span class="BOLD">0</span> results</h1></body></html>`;
export const SIGNIN = `<html><head><title>Sign in or Register | eBay</title></head><body><form id="signin-form"><input name="userid"></form></body></html>`;
export const CAPTCHA = `<html><head><title>Pardon Our Interruption</title></head><body>Please verify yourself to continue. captcha</body></html>`;
export const ODD = '<html><head><title>garlic | eBay</title></head><body>' + '<div>some new layout we do not know yet</div>'.repeat(300) + '</body></html>';
