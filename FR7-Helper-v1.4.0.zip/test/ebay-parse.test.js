import test from 'node:test'; import assert from 'node:assert/strict'; import { createRequire } from 'node:module';
import { OLD, NEW, SOLD, NONE, SIGNIN, CAPTCHA, ODD } from './fixtures.js';
const require = createRequire(import.meta.url), P = require('../src/ebay-parse.js');

test('numbers and currencies', () => {
  assert.equal(P.num('1,234.56'), 1234.56); assert.equal(P.num('1.234,56'), 1234.56); assert.equal(P.num('12,50'), 12.5); assert.equal(P.num('1,234'), 1234); assert.equal(P.num('1.234'), 1234); assert.equal(P.num('abc'), null);
  assert.equal(P.currencyOf('US $5'), 'USD'); assert.equal(P.currencyOf('£5.00'), 'GBP'); assert.equal(P.currencyOf('EUR 5,00'), 'EUR'); assert.equal(P.currencyOf('C $5'), 'CAD'); assert.equal(P.currencyOf('AU $5'), 'AUD');
  assert.equal(P.dateOf('Nov 20, 2026'), Date.UTC(2026, 10, 20) / 1000); assert.equal(P.dateOf('3 Oct 2026'), Date.UTC(2026, 9, 3) / 1000); assert.equal(P.dateOf('nonsense'), null);
});
test('old layout: total, items, sold quantity, seller, location, ranges, placeholder skipped', () => {
  const r = P.parse(OLD); assert.equal(r.total, 1234); assert.equal(r.layout, 's-item'); assert.equal(r.items.length, 2, '"Shop on eBay" placeholder is dropped');
  const a = r.items[0]; assert.equal(a.id, '111111111111'); assert.equal(a.title, 'Silicone Garlic Press & Peeler'); assert.equal(a.cents, 1299); assert.equal(a.cur, 'USD'); assert.equal(a.sold_qty, 1234); assert.equal(a.seller, 'gadgetshop'); assert.equal(a.ship_from, 'China');
  assert.equal(a.url, 'https://www.ebay.com/itm/111111111111'); assert.match(a.img, /^https:\/\/i\.ebayimg\.com\//);
  const b = r.items[1]; assert.equal(b.id, '222222222222'); assert.equal(b.cents, 800, 'a price range takes the first price'); assert.equal(b.sold_qty, null); assert.equal(b.seller, 'kitchenking');
});
test('new layout: lazy image, sold date, sold quantity, location', () => {
  const r = P.parse(NEW); assert.equal(r.total, 45); assert.equal(r.layout, 's-card'); assert.equal(r.items.length, 1); const a = r.items[0];
  assert.equal(a.title, 'Garlic Mincer Tool'); assert.equal(a.cents, 850); assert.equal(a.sold_qty, 12); assert.equal(a.sold_at, Date.UTC(2026, 10, 20) / 1000); assert.equal(a.ship_from, 'Germany'); assert.equal(a.img, 'https://i.ebayimg.com/images/g/zz/s-l500.jpg');
});
test('sold page: dates in two formats', () => {
  const r = P.parse(SOLD, { sold: true }); assert.equal(r.total, 3010); assert.deepEqual(r.items.map(i => i.sold_at), [Date.UTC(2026, 10, 20) / 1000, Date.UTC(2026, 9, 3) / 1000]); assert.deepEqual(r.items.map(i => i.cents), [1400, 1600]);
});
test('no results, sign-in, captcha, unknown layout', () => {
  const n = P.parse(NONE); assert.equal(n.total, 0); assert.equal(n.no_results, true); assert.equal(n.unrecognized, false);
  assert.equal(P.parse(SIGNIN).login, false); assert.equal(P.parse(CAPTCHA).captcha, true);
  const o = P.parse(ODD); assert.equal(o.unrecognized, true); assert.equal(o.items.length, 0); assert.equal(P.parse('').captcha, true, 'a tiny empty page is treated as a block, not as zero results');
});
