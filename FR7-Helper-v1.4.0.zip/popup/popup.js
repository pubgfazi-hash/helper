const $ = (id) => document.getElementById(id);
const SERVER = FR7_CONFIG.origins[0];   // one server; the code alone decides
const MSG = { bad_code: 'That code does not look right. Copy it again from the website.', network: 'Could not reach the server. Check your internet and try again.', internal: 'Something went wrong. Try again.' };
function show(paired) {
  $('s').textContent = paired ? 'Connected' : 'Not connected'; $('dot').className = 'dot' + (paired ? ' on' : '');
  $('d').textContent = paired ? 'Ready. The website can use this browser when needed.' : 'On the FR7 website, open Settings, Browser helper, create a code, and type it here.';
  $('f').style.display = paired ? 'none' : 'block';
}
chrome.runtime.sendMessage({ type: 'status' }).then((s) => show(!!(s && s.paired))).catch(() => show(false));
$('b').addEventListener('click', async () => {
  const code = $('c').value.trim(); $('e').textContent = ''; if (!code) { $('e').textContent = 'Type the code first.'; return; }
  $('b').disabled = true; $('b').textContent = 'Connecting...';
  try {
    const r = await chrome.runtime.sendMessage({ type: 'pair-manual', code, server: SERVER });
    if (r && r.ok) show(true); else $('e').textContent = 'Refused: ' + (MSG[r && r.error] || (r && r.error) || 'unknown') + ' Create a NEW code on the website (works once, 10 minutes).';
  } catch (e) { $('e').textContent = MSG.internal; }
  $('b').disabled = false; $('b').textContent = 'Connect';
});
